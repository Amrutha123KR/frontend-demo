# React Frontend Deployment Pipeline

This repository contains a React.js frontend application deployed to **AWS S3** using **Jenkins CI/CD**.

## Pipeline Flow
1. Developer pushes code to GitHub.
2. Jenkins pulls code.
3. Jenkins runs:
   - `npm install`
   - `npm run build`
4. Jenkins uploads the build folder to **AWS S3**.

## Requirements
- AWS S3 bucket
- Jenkins with AWS Credentials (`aws-jenkins-creds`)
- Node.js + NPM installed on Jenkins server
